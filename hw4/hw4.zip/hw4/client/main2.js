// const { brotliCompress } = require("zlib");

// set global variable todos
const queryString = window.location.search
const urlParams = new URLSearchParams(queryString);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////CHECK-IN FOR BOARDING PASS///////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Check-in button to get to Boarding Pass
const checkin = () => {
  /* const todoTable = document.querySelector('#checkin-form-box');
  const todoList = document.querySelector(); 
  let checkinHTML = "";
  tickets.map(ticket =>{
    checkinHTML += `<button type="button" class="btn" id="btnCheckIn" onclick="displayBoardingPass('${ticket.ticketId}')">CHECK-IN</button>`;
  }) */
  document.querySelector("#btnCheckIn").addEventListener("click", function () { displayBoardingPass() });
}


//Display Boarding Pass after hitting the CHECK-IN button
async function displayBoardingPass() {
  const firstname = document.getElementById("fname").value;
  const lastname = document.getElementById("lname").value;
  /*const book_ref = document.getElementById("bref").value; */
  const ticket_no = document.getElementById("ticketno").value;
  const body = { firstname, lastname, ticket_no };
  let boarding_passes = ""
  let displayed_ticket_no = ""
  let countTrip = 0
  const response = await fetch(`http://localhost:5000/result_boarding_pass`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })

  const returned_result = await response.json();
  console.log(returned_result)
  if (returned_result.length == 0)
    boarding_passes = "<div><h1>BOARDING PASS: No result</h1>"



  returned_result.map(data => {
    if (data.ticket_no !== displayed_ticket_no) {
      displayed_ticket_no = data.ticket_no
      boarding_passes += `
      <div><h1>BOARDING PASS</h1>
      <div class="bpfrom">Passenger ID:  ${data.passengerid} </div>
      <div class="bpfrom">First Name:  ${data.first_name} </div>
      <div class="bpfrom">Last Name:  ${data.last_name} </div>
      <div class="bpfrom">Ticket No.:  ${data.ticket_no} </div>
      </div>
      </br>
    `

    }
    boarding_passes += `
                        
                         
      </br><hr>
                          <div class="bpfrom">Flight ID:  ${data.flight_id} | Flight No:   ${data.flight_no} </div>
                          <div class="bpfrom">FROM:   ${data.departure_airport} </div>
                          <div class="bpfrom">TO:  ${data.arrival_airport} </div>
                          <div class="bpfrom">Departing Gate:  ${data.gateId_depart == undefined ? "N/A" : data.gateId_depart} </div>
                          <div class="bpfrom">Arriving Gate: ${data.gateId_arrival == undefined ? "N/A" : data.gateId_arrival} </div>
                          <div class="bpfrom">Seat No.:  ${data.seat_no} | Baggage Claim Sec.:  ${data.baggage_claim_no} </div>
                        `;

  })
  // boarding_passes += `</div>`
  document.getElementById("output").innerHTML = boarding_passes;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////DISPLAY WAITLIST///////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const waitlistbtn = () => {
  /* const todoTable = document.querySelector('#checkin-form-box');
  const todoList = document.querySelector(); 
  let checkinHTML = "";
  tickets.map(ticket =>{
    checkinHTML += `<button type="button" class="btn" id="btnCheckIn" onclick="displayBoardingPass('${ticket.ticketId}')">CHECK-IN</button>`;
  }) */
  document.querySelector("#btnWaitlist").addEventListener("click", function () { displayWaitList() });
}

//Display Waitlist
async function displayWaitList() {
  // const firstname = document.getElementById("fname").value;
  // const lastname = document.getElementById("lname").value;
  // const flightid = document.getElementById("flightid").value;
  // const flightno = documnet.getElementById("flightno").value;
  // const ticket_no = document.getElementById("ticketno").value;
  // firstname, lastname, flightid, flightno, ticket_no
  const body = {  };

  const response = await fetch(`http://localhost:5000/result_waitlist`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })

  const returned_result = await response.json();
  console.log(returned_result)
  let waitlist = ""
  returned_result.map(data => {
    waitlist += `<div style='background-color:white'>
            <div>Book_ref: ${data.book_ref} </div>
            <div>Ticket_no:${data.ticket_no} </div>
            <div>First name:${data.first_name} </div>
            <div>Last name:${data.last_name} </div>
                        </div><hr>`;
  })

  document.getElementById("output1").innerHTML = waitlist;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////REFUND/////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const refundbtn = () => {
  /* const todoTable = document.querySelector('#checkin-form-box');
  const todoList = document.querySelector(); 
  let checkinHTML = "";
  tickets.map(ticket =>{
    checkinHTML += `<button type="button" class="btn" id="btnCheckIn" onclick="displayBoardingPass('${ticket.ticketId}')">CHECK-IN</button>`;
  }) */
  document.querySelector("#btnRefund").addEventListener("click", function () { displayRefund() });
}

async function displayRefund() {
  const ticket_no = document.getElementById("ticket_no").value;
  /*const book_date = document.getElementById("bookdate").value;*/
  // const firstname = document.getElementById("fname").value;
  // const lastname = document.getElementById("lname").value;
  const body = { ticket_no };

  const response = await fetch(`http://localhost:5000/result_refund`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })

  const returned_result = await response.json();
  console.log(returned_result)
  let refundpayment = ""
  if (returned_result.length <=0){
    refundpayment = "Refund information is missing. Call the airport for more information"
    
  }
  returned_result.map(data => {
    refundpayment += `<div>
    <h1>REFUND PAYMENT INFORMATION</h1>   
    <div class="refundreturn">Refund Amount: $${parseFloat(data.amount)*(-1)}</div></div>`;

  })
  document.getElementById("message").innerHTML = refundpayment;

  // <div class="refundreturn">Last Name: ${data.last_name}</div>
  // <div class="refundreturn">First Name: ${data.first_name}</div>
  // <div class="refundreturn">Ticket No.: ${data.ticket_no}</div>
  // <div class="refundreturn">Booking Date: ${data.book_date}</div>
  // <div class="refundreturn">Flight ID: ${data.flight_id}</div>
  // <div class="refundreturn">Total Cost: $${data.total_cost}</div>
  // <div class="refundreturn">Cancel Date: ${data.cancel_date}</div>
}
//-------------------- AIRLINE CLERK--------------------------------
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////LIST NUMBER OF PASSENGERS ON EACH FLIGHT/////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const passonflight = () => {
  /* const todoTable = document.querySelector('#checkin-form-box');
  const todoList = document.querySelector(); 
  let checkinHTML = "";
  tickets.map(ticket =>{
    checkinHTML += `<button type="button" class="btn" id="btnCheckIn" onclick="displayBoardingPass('${ticket.ticketId}')">CHECK-IN</button>`;
  }) */
  document.querySelector("#btninfo").addEventListener("click", function () { displayTotalPassengeronFlight() });
  document.querySelector("#btncheck").addEventListener("click", function () { displayPassengerEachSeat() });
}

async function displayTotalPassengeronFlight() {
  const flightid = document.getElementById("flightid").value;
  const body = { flightid };

  const response = await fetch(`http://localhost:5000/result_total_passengers`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })

  const returned_result = await response.json();
  console.log(returned_result)
  let flightdetail1 = ""
  if (returned_result.length==0) {
    flightdetail1 += `<div>
    <h1>NUMBER OF PASSENGERS ON FLIGHT ${flightid}</h1>   

    <div class="info">Flight ID: ${flightid}</div>
    
    <div class="info">Total Passengers: ${0}</div></div>`;
  }
  returned_result.map(data => {
    flightdetail1 += `<div>
    <h1>NUMBER OF PASSENGERS ON FLIGHT ${data.flight_id}</h1>   

    <div class="info">Flight ID: ${data.flight_id}</div>
    <div class="info">Flight No: ${data.flight_no}</div>
    <div class="info">Total Passengers: ${data.total_passengers}</div></div>`;

  })
  document.getElementById("output").innerHTML = flightdetail1;
}

async function displayPassengerEachSeat() {
  const flightid = document.getElementById("flightid").value;
  const body = { flightid };

  const response = await fetch(`http://localhost:5000/result_each_seats`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })

  const returned_result = await response.json();
  console.log(returned_result)
  let flightdetail2 = ""
  returned_result.map(data => {
    flightdetail2 += `<div>
    <h1>NUMBER OF PASSENGERS ON ALL FLIGHTS</h1>   

    <div class="info">Flight ID: ${data.flight_id}</div>
    <div class="info">Total Passengers: ${data.total_passengers}</div>
    <div class="info">Seat No: ${data.seat_no}</div>
    <div class="info">Departure Airport: ${data.departure_airport}</div>
    <div class="info">Arrival Airport: ${data.arrival_airport}</div>
    </div>`;
  })
  document.getElementById("output1").innerHTML = flightdetail2;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////CANCELLATION/////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


async function updateCancellation() {
  DOMconfirm = document.querySelector("#message")
  DOMconfirm.classList.remove("hidden")

  console.log("click cancel")
  const ticket_no = document.querySelector('#ticket_no').value;
  const book_ref = document.querySelector('#bookref').value;
  if (ticket_no == "" || book_ref == "") {
    DOMconfirm.innerHTML = "Need at least ticket number and booking reference";
  } else {
    try {
      const body = { ticket_no, book_ref };
      const response = await fetch(`http://localhost:5000/cancel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      })
      jsonData = await response.json()
      console.log(jsonData)


      DOMconfirm.innerHTML = jsonData.message;
    } catch (err) {
      console.log(err.message);
    }
  }
}

// ULTIL FUNCTIONS

function str_trim(str) {
  str = str.trim()
  if (str.length < 1)
    return null;
  return str
}

function convertDate(date) {
  D = new Date(date)
  // D=Date.parse(date)
  return (D.getMonth() + 1) + "-" + D.getDate() + "-" + D.getFullYear()
}
function getUUID() {
  return uuidv4().substr(0, 6).trim()
}
function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}



