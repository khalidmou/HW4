// set global variable todos
let todos = []
let tickets = []
let passengers = []
let DataLocationFrom = []
let DataLocationTo = []
let numberOfPassenger = 1
let seat1s = []
let seat2s = []
let seat3s = []
let seat_takens = []
let currentTicketId = ""
let maxPassenger = 0
let seatForCurrentPassenger = ""
let seatForCurrentPassenger_Price = 0
let book_ref = ""
let flights = []
let glo_payment = {}
let current_fl_id = 0
let fl_price = 0
let total_amount_to_pay = 0
const queryString = window.location.search
const urlParams = new URLSearchParams(queryString);
let total_fl = 0
let total_fl_id = 0
const setLocationFrom = (data) => {
  DataLocationFrom = data
}

const setLocationTo = (data) => {
  DataLocationTo = data
}

const setSeat1s = (data) => {
  seat1s = data
  // console.log(data)
}
const setSeat2s = (data) => {
  seat2s = data
  // console.log(data)
}
const setSeat3s = (data) => {
  seat3s = data
  // console.log(data)
}

const setBook_ref = (data) => {
  book_ref = data
  console.log("bookref:" + data)
}





// function to set todos
const setTodos = (data) => {
  todos = data;
}
const addTicketData = (ticket) => {

  console.log(ticket.seatNo)
  if (tickets.length < numberOfPassenger) {
    tickets.push(ticket)

    seatListInString = "totalSeat:" + current_seat_obj.length
    current_seat_obj.forEach((data, i) => {
      seatListInString += `|${data.seatNo}-${data.flight_id}-${data.price}`
    })

    jsonStr = JSON.stringify(ticket)
    setCookie(ticket.ticketId, jsonStr)
    // setCookie("ticketId", ticket.ticketId + "," + "firstName:" + ticket.firstName + "," + "lastName:" + ticket.lastName + "," + "email:" + ticket.email + "," + "phone:" + ticket.phone + "," + "checked_bags_no:" + ticket.checked_bagno + ",seat:" + ticket.seatListInString + ",amount:" + ticket.amount
    // + ",isMovie:" + ticket.isMovie + ",isMeal:" + ticket.isMeal)
    current_seat_obj = []
    // currentTicketId= ticket.ticketId
  }
  else
    console.log("full tickets")
  console.log(tickets)
  if (tickets.length < maxPassenger) {//to reset
    currentTicketId = getUUID_Ticket()
    seatForCurrentPassenger = ""
  }
  else {
    console.log("max out passenger")
    currentTicketId = ""
    document.querySelector('#seat-table').classList.add("hidden");
    document.querySelector('#div-passenger-info').classList.add("hidden");
    document.querySelector('#btnAddTicket').classList.add("hidden");
    document.querySelector('#btnShowPayment').classList.remove("hidden");
  }
  displayTickets()
}

const deleteTicketAPI = (ticketId) => {
  document.querySelector('#seat-table').classList.remove("hidden");
  document.querySelector('#div-passenger-info').classList.remove("hidden");
  document.querySelector('#btnAddTicket').classList.remove("hidden");
  document.querySelector('#btnShowPayment').classList.add("hidden");

  // document.querySelector('#div-payment-info').classList.add("hidden")
  ticketId = ticketId.trim()
  tickets.filter((ticket, index, arr) => {
    if (ticket.ticketId == ticketId) {
      tickets.splice(index, 1);
      return
    }
  })

  currentTicketId = ticketId
  console.log(tickets)
  displayTickets()
}

const deleteTicket = (ticketId) => {

  deleteTicketAPI(ticketId)
  //remove seat array
  var seatTaken = ""
  seat_takens.filter((data) => {
    if (data.ticketId === ticketId) {
      console.log(data.ticketId === currentTicketId);
      seatTaken = data.seatNo
    }
  });
  if (document.querySelector('#seat-' + seatTaken) != null) {
    document.querySelector('#seat-' + seatTaken).classList.remove('btn-warning');
  }
}


// function edit todo
const editTodo = (id) => {
  const descrip = todos.filter(todo => todo.todo_id === id)[0].description;
  document.querySelector('#edited-description').value = descrip;
  document.querySelector('#save-edit-description').addEventListener("click", function () { updateTodo(id) });
}

const editPassenger = (ticketId) => {

  const ticket = tickets.filter(ticket => ticket.ticket_no == ticketId);
  console.log(ticket)
  // currentTicketId= ticketId
  // document.querySelector('#edited-Lastname').value = descrip;
  // document.querySelector('#edited-Firstname').value = descrip;
  // document.querySelector('#save-edit-passenger').addEventListener("click", function() {updateTicket(ticketId)});
}

function getCookie(key) {
  str = document.cookie.split('; ').find(row => row.startsWith(key))
  if (str != undefined)
    return JSON.parse(str.substr(str.indexOf('=') + 1, str.length));

  // let cookie = document.cookie.split('; ').find(row => row.startsWith(key))
  // if (cookie != undefined)
  //   return cookie.split('=')[1]
  return undefined
}

function getCookieText(key) {
  str = document.cookie.split('; ').find(row => row.startsWith(key))
  if (str != undefined)
    return str.split('=')[1];
  // let cookie = document.cookie.split('; ').find(row => row.startsWith(key))
  // if (cookie != undefined)
  //   return cookie.split('=')[1]
  return undefined
}
function getCustomParam(str, key) {
  result = str.split('&').find(row => row.startsWith(key))
  console.log(result)
  if (result != undefined)
    return result.split('=')[1]
  return undefined
}


// function edit todo
const chooseFlight = (str,date) => {
  // setCookie()
  console.log(str)
  // 'total_fl=2&pasNo=${selectNumberOfPassenger}&fl_no=${data.flight1},${data.flight2}&fl_id=${data.flight_id_1},${data.flight_id_2}&price=${data.fl_price}'
  round = false
  str.split('&').forEach((data, i) => {
    split = data.split('=')
    if (split[0] == "round" && split[1] == "true") {
      round = true
      console.log("set round =" + round)
      return false;
    }
  })
  if (round) {
    console.log("round=" + round)
    if (getCookie("fl_from_set") != undefined) {
      if (getCookie("fl_from_set").data != undefined) {
        setCookie("fl_to_set", JSON.stringify({ data: str }))
        setCookie("trip2_from", getCustomParam(str, "from_airport"))
        setCookie("trip2_to", getCustomParam(str, "to_airport"))
        str = getCookie("fl_from_set").data
        // total_fl = getCustomParam(str, "total_fl")
        setCookie("total_fl", total_fl)
        pasNo = getCustomParam(str, "pasNo")
        fl_no = getCustomParam(str, "fl_no")
        fl_id = getCustomParam(str, "fl_id")
        price = getCustomParam(str, "price")
        from_airport = getCustomParam(str, "from_airport")
        to_airport = getCustomParam(str, "to_airport")
        str = getCookie("fl_to_set").data
        fl_no += "," + getCustomParam(str, "fl_no")
        fl_id += "," + getCustomParam(str, "fl_id")
        price += "," + getCustomParam(str, "price")
        from_airport += "," + getCustomParam(str, "from_airport")
        to_airport += "," + getCustomParam(str, "to_airport")
        rebuildStr = "round=true&total_fl=" + total_fl + "&pasNo=" + pasNo + "&fl_no=" + fl_no +
          "&fl_id=" + fl_id + "&price=" + price + "&from_airport=" + from_airport + "&to_airport=" + to_airport

        console.log("rebuilt = " + rebuildStr)

        location.href = "/?" + rebuildStr
      }
    } else {
      setCookie("fl_from_set", JSON.stringify({ data: str }))
      setCookie("trip1_from", getCustomParam(str, "from_airport"))
      setCookie("trip1_to", getCustomParam(str, "to_airport"))
      setCookie("arrival_first_trip", date)
      console.log()
      OrderTicket(true)
    }
  } else {
    setCookie("fl_from_set", JSON.stringify({ data: str }))
    setCookie("trip1_from", getCustomParam(str, "from_airport"))
    setCookie("trip1_to", getCustomParam(str, "to_airport"))


    console.log("go directly to flight")
    location.href = "/?" + str
  }

  // str.split('&').forEach((data, i) => {
  //   split = data.split('=')
  //   if (split[0] == "round" && split[1] == "true") {
  //     round = true
  //   }
  //   // getCookie("test") == ""

  //   // if ((split[0]== "fl_no" || split[0]== "fl_id" ) && split[1].split(',').length>1){
  //   //   // console.log("data inside:")
  //   //   split[1].split(',').forEach((d)=>{
  //   //     console.log(d)
  //   //   })
  //   // }

  // })

  // const descrip = todos.filter(todo => todo.todo_id === id)[0].description;
  // document.querySelector('#edited-description').value = descrip;
  // document.querySelector('#save-edit-description').addEventListener("click", function() {updateTodo(id)});



}

const displaySelectFrom = () => {
  selectFrom = ""
  const DOMselectFrom = document.getElementById("selectFrom");
  DataLocationFrom.map(data => {
    selectFrom +=
      `<option value=${data.airport_code}>${data.airport_name + '(' + data.airport_code + ')'}</option>`;
  })
  console.log("display select From")
  // console.log(DataLocationFrom)
  DOMselectFrom.innerHTML = selectFrom
}

const displaySelectTo = () => {
  selectTo = ""
  const DOMselectTo = document.getElementById("selectTo");
  DataLocationTo.map(data => {
    selectTo +=
      `<option value=${data.airport_code}>${data.airport_name + '(' + data.airport_code + ')'}</option>`;
  })
  console.log("display select To")
  // console.log(DataLocationTo)
  DOMselectTo.innerHTML = selectTo
}

const displaySeat = (flight_id) => {//from, to) => {
  const seatTable = document.querySelector('#seat-tbody');
  // display all todos by modifying the HTML in "todo-table"

  //set for local use
  seats = seat1s
  // if (flNo == 1) { seats = seat1s }
  // else if (flNo == 2) { seats = seat2s }
  // else if (flNo == 3) { seats = seat3s }

  // console.log(seats)
  DOMseat = `<tr> <th colspan="6">For flight_id ${flight_id} from to </th></tr>`

  DOMseat += `<tr>`
  seats.map((seat, index) => {
    if (index % 7 == 0)
      DOMseat += `</tr><tr>`
    DOMseat += ` <td><button class="btn" type="button" id="seat-${flight_id + seat.seat_no}" style="${fareConditionColor(seat.fare_conditions)}"
    onclick="if(this.classList.contains('btn-warning')) {return false;}chooseSeat('${flight_id}','${seat.seat_no}','${seat.seat_price}');">${seat.seat_no}</button></td>`;
    if (index == seats.length - 1 && index % 7 != 0)
      DOMseat += `</tr>`
  })

  seatTable.innerHTML += DOMseat;
}


const displayTickets = () => {
  const todoTable = document.querySelector('#passenger-table');
  const todolist = document.querySelector('#passenger-tbody'); //this is show table
  todoTable.classList.remove('hidden')
  // display all todos by modifying the HTML in "todo-table"
  let tableHTML = "";
  tickets.map(ticket => {
    tableHTML +=
      `<tr key=${ticket.lastName}>
    <th>${ticket.lastName}</th>
    <th>${ticket.firstName}</th>
    <th><button class="btn btn-warning" type="button" onclick="editTicket('${ticket.ticketId}','${ticket.lastName}','${ticket.firstName}','${ticket.email}','${ticket.phone}','${ticket.checked_bags_no}','${ticket.isMovie}','${ticket.isMeal}')">Edit</button></th>
    </tr>`;
  })
  // <th><button class="btn btn-danger" type="button" onclick="deleteTicket('${ticket.ticketId}')">Delete</button></th>
  todolist.innerHTML = tableHTML;
}

// select all the todos when the codes first run


// The following are async function to select, insert, update and delete todos
// select all the todos
async function loadingData() {
  // use try... catch... to catch error
  try {
    console.log("loading...")
    //for list flight from
    const response1 = await fetch("http://localhost:5000/fl_from")
    const jsonData1 = await response1.json();
    //for list flight to
    const response2 = await fetch("http://localhost:5000/fl_to")
    const jsonData2 = await response2.json();

    // GET all todos from "http://localhost:5000/todos"
    // const response3 = await fetch("http://localhost:5000/todos")
    // const jsonData3 = await response3.json();

    setLocationFrom(jsonData1);
    setLocationTo(jsonData2);
    // setTodos(jsonData3);
    // displayTickets();
    displaySelectFrom();
    displaySelectTo();

    loadingDOMPassengerNumber()
  } catch (err) {
    console.log(err.message);
    document.getElementById("message-box").classList.remove("hidden")
    document.getElementById("message-content").innerHTML = err.message;
    document.getElementById("div-error-message").classList.remove("hidden")
    document.getElementById("div-error-message").innerHTML = err.message;
  }
}


const loadingDOMPassengerNumber = () => {
  const DOMselectNumberOfPassenger = document.getElementById("selectNumberOfPassenger");
  DOMoption = ""
  for (i = 1; i <= 5; i++) {
    DOMoption += `<option value=${i}>${i}</option>`;
  }
  console.log("display select number of passenger")
  DOMselectNumberOfPassenger.innerHTML = DOMoption
}

async function loadSeatAvalability(flight_id) {
  console.log("loading for flight_id=" + flight_id)
  // use try... catch... to catch error
  try {
    console.log("loading seats")
    //for list flight from
    body = { flight_id };
    const response = await fetch("http://localhost:5000/seat_available", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })
    const jsonData = await response.json();
    setSeat1s(jsonData)

    displaySeat(flight_id)//urlParams.get('from_airport').split(',')[flightNo - 1])
  } catch (err) {
    console.log(err.message);
    document.getElementById("div-error-message").classList.remove("hidden")
    document.getElementById("div-error-message").innerHTML = err.message;
    document.getElementById("message-box").classList.remove("hidden")
    document.getElementById("message-content").innerHTML = err.message;
  }
}

async function loadingFlightDetails(arr_from_airports, arr_to_airports) {
  html = ""
  // if (arr_from_airports.length != arr_to_airports.length) {
  //   console.log("bug here ")
  //   return
  // }

  // total_fl = getCookie("total_fl")
  let trip1_airport_from = getCookieText("trip1_from").split(',')
  let trip1_airport_to = getCookieText("trip1_to").split(',')
  let trip2_airport_from = getCookieText("trip2_from")
  let trip2_airport_to = getCookieText("trip2_to")
  if (trip2_airport_from != undefined)
    trip2_airport_from = trip2_airport_from.split(',')
  if (trip2_airport_to != undefined)
    trip2_airport_to = trip2_airport_to.split(',')
  html = `<div class="row">
  <div class="col-md-12">
  <h1> Trip ${1} </h1>
  </div>
  </div>`
  trip1_airport_from.forEach((data, i) => {
    html += `<div class="row">
    <div class="col-md-12">
      <fieldset>
        <h5> Flight ${i + 1}</h5>
      </fieldset>
    </div>

    <div class="col-md-6">
        <fieldset>
          <label for="to">Departure:${data}</label>
        </fieldset>
    </div>

    <div class="col-md-6">
      <fieldset>
        <label for="to">Arrival:${trip1_airport_to[i]}</label>
      </fieldset>
    </div>
  </div>`

  })


  if (trip2_airport_from != undefined) {

    html += `<div class="row">
  <div class="col-md-12">
  <h1> Trip ${2} </h1>
  </div>
  </div>`
    trip2_airport_from.forEach((data, i) => {


      html += `<div class="row">
  <div class="col-md-12">
    <fieldset>
      <h5> Flight ${i + 1}</h5>
    </fieldset>
  </div>

  <div class="col-md-6">
      <fieldset>
        <label for="to">Departure:${data}</label>
      </fieldset>
  </div>

  <div class="col-md-6">
    <fieldset>
      <label for="to">Arrival:${trip2_airport_to[i]}</label>
    </fieldset>
  </div>
</div>`

    })
  }

  document.querySelector('#flight-info').innerHTML = html
  document.querySelector('#flight-info').classList.remove("hidden")
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// CLIENT JAVASCRIPT ACTION ONLY ///////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
async function EventAddTicket() {
  if (current_seat_obj.length < total_fl_id) {
    console.log("need to add SEAT")
    document.getElementById("message-box").classList.remove("hidden")
    document.getElementById("message-content").innerHTML = "need to add SEAT";
    document.getElementById("div-error-message").classList.remove("hidden")
    document.getElementById("div-error-message").innerHTML = "need to add SEAT";
    return
  }
  var firstName = document.querySelector('#inputFirstname').value
  var lastName = document.querySelector('#inputLastname').value
  var email = document.querySelector('#inputEmail').value
  var phone = document.querySelector('#inputPhone').value
  var phone = document.querySelector('#inputPhone').value
  var checked_bagno = document.querySelector('#selectCheckedBag').value
  var isMovie = document.querySelector('#cbIsMovie').checked
  var isMeal = document.querySelector('#cbIsMeal').checked
  document.querySelector('#inputFirstname').value = ""
  document.querySelector('#inputLastname').value = ""
  document.querySelector('#inputEmail').value = ""
  document.querySelector('#inputPhone').value = ""
  document.querySelector('#inputPhone').value = ""
  document.querySelector('#selectCheckedBag').selectedIndex = 0
  document.querySelector('#cbIsMovie').checked = false
  document.querySelector('#cbIsMeal').checked = false

  // console.log(currentTicketId)

  // console.log(document.cookie)
  addTicketData({
    ticketId: currentTicketId, firstName, lastName, email, phone, seatNo: current_seat_obj,
    passengerId: -1, checked_bags_no: checked_bagno, flights, isMovie, isMeal, amount: (parseFloat(fl_price))
  })
  window.scrollTo(0, 0);
}
function EventGoToRoundBack() {
  location.href = location.pathname + location.search + "&round=true"

}

function deleteCookie() {
  console.log("refresh the cookie, nothing now :" + document.cookie)
  let d = new Date();
  d.setTime(d.getTime() + (0 * 15 * 60 * 1000));
  let expires = "expires=" + d.toUTCString();
  document.cookie.split(';').forEach(data => {
    console.log(data.split('=')[0])
    document.cookie = data.split('=')[0] + "=" + ";" + expires + ";path=/";
  })


}

function setCookie(cname, cvalue) {
  console.log("set cookie:" + cname + "=" + cvalue)
  let d = new Date();
  d.setTime(d.getTime() + (1 * 15 * 60 * 1000));
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
async function EventShowPayment() {//only hide the btn for add
  amount = 0 + fl_price
  console.log(amount)
  amount = amount * parseInt(maxPassenger)
  console.log(amount)
  document.querySelector('#div-payment-info').classList.remove("hidden")
  document.querySelector('#btnAddPayment').classList.remove("hidden")
  document.querySelector('#btnShowPayment').classList.add("hidden")

  // seat_takens.forEach((seat) => {
  //   // console.log(seat.seat_price)
  //   amount += parseFloat(seat.seat_price)
  // })
  tickets.forEach((ticket) => {
    ticket.seatNo.forEach(seat => {
      console.log(seat.price)
      amount += parseFloat(seat.price)
    })
  })
  amount = (amount * 1.085).toFixed(2)
  total_amount_to_pay = amount
  document.querySelector('#lbTotalAmount').innerHTML = "$" + amount;
  console.log("add payment click")
  // AddPassenger()
}

async function EventAddPayment() {// will proceed everything and confirm 
  console.log("start adding this to server")
  glo_payment = {
    cardHolder: document.querySelector('#inputCardHolder').value,
    cardNumber: document.querySelector('#inputCardNumber').value,
    CVV: document.querySelector('#inputCVV').value,
    EXP: new Date(document.querySelector('#inputEXP').value),
    amount: total_amount_to_pay
  }

  //submit everything 
  console.log(tickets); // this is infor of passenger OR ticket
  tickets.filter((data, index) => {
    seat_takens.forEach(seat => {
      if (data.ticketId == seat.ticketId) {
        tickets[index].seatNo = seat.seatNo
        tickets[index].price = seat.seat_price
        console.log(tickets[index].seatNo)
        return false;
      }
    })
  })
  console.log(seat_takens.length < 1 ? "seat random" : seat_takens)// should be in TICKET
  console.log(glo_payment)
  console.log("save payment and proceed to confirmation page before hit FINALIZE, SHOULD SAVE ALL IN DB")
  PreFinalize()
}

const editTicket = (id, ln, fn, email, phone, t_checked_bag_no, isMovie, isMeal) => {
  console.log({ t_checked_bag_no, isMovie, isMeal })

  document.querySelector('#inputFirstname').value = fn
  document.querySelector('#inputLastname').value = ln
  document.querySelector('#inputEmail').value = email
  document.querySelector('#inputPhone').value = phone
  document.querySelector('#selectCheckedBag').selectedIndex = t_checked_bag_no

  // console.log(isMovie)
  // console.log(isMeal)
  // document.querySelector('#cbIsMovie').setAttribute("checked", isMovie);
  document.querySelector('#cbIsMovie').checked = isMovie == "false" ? false : true

  // document.querySelector('#cbIsMeal').setAttribute("checked", isMeal);
  document.querySelector('#cbIsMeal').checked = isMeal == "false" ? false : true

  // console.log(document.querySelector('#cbIsMovie').checked)
  // console.log(document.querySelector('#cbIsMeal').checked)
  // checked_bags_no
  currentTicketId = id
  tickets.forEach((data, i) => {
    if (data.ticketId == id) {
      console.log(current_seat_obj)
      current_seat_obj = data.seatNo
      console.log(current_seat_obj)
    }
  })

  deleteTicketAPI(id)
  //addTicketData({ticketId:id, firstName:fn, lastName:ln, email:email, phone:phone})
}
let current_seat_obj = []


const checkMaxTheSeatFlight = (flight_id) => {
  flag = false
  current_seat_obj.forEach((data) => {
    if (data.flight_id === flight_id) {
      flag = true
      return true;
    }
  });
  return flag
}


const checkExistSeatForCurrentPassenger = (seatNo, flight_id) => {
  current_seat_obj.forEach((data) => {
    if (data.seatNo === seatNo && data.flight_id === flight_id) {
      return true;
    }
  });
  return false
}

const addSeatForCurrentPassenger = (seatNo, flight_id, price) => {
  if (current_seat_obj.length == total_fl_id) {
    console.log("max out already")
    return false
  }

  if (checkExistSeatForCurrentPassenger(seatNo, flight_id) == false) {
    // console.log("add seat")
    // console.log({ seatNo: seatNo, flight_id: flight_id, price: price })
    current_seat_obj.push({ seatNo: seatNo, flight_id: flight_id, price: price })
    return seatNo;
  }
  return seatNo;
}

const removeSeatForCurrentPassenger = (seatNo, flight_id) => {
  current_seat_obj.forEach((data, i) => {
    if (data.seatNo === seatNo && data.flight_id === flight_id) {
      current_seat_obj.splice(i, 1);
      return true;
    }
  });
}

const editSeatForCurrentPassenger = (seatNo, flight_id, price) => {
  returnData = ''
  console.log(current_seat_obj)
  current_seat_obj.forEach((data, i) => {
    if (data.flight_id === flight_id) {

      returnData = current_seat_obj[i].seatNo

      current_seat_obj[i].seatNo = seatNo
      current_seat_obj[i].price = price
      return;
    }
  });
  return returnData
}

const chooseSeat = (flNo, seatNo, price) => {
  console.log(seatNo)
  if (currentTicketId != "") {
    seatForCurrentPassenger = seatNo
    seatForCurrentPassenger_Price = parseFloat(price)
    console.log(checkMaxTheSeatFlight(flNo))
    if (checkMaxTheSeatFlight(flNo) == true) {// already has seat for this flight
      console.log(current_seat_obj)
      let oldseatNo = editSeatForCurrentPassenger(seatForCurrentPassenger, flNo, seatForCurrentPassenger_Price)
      // console.log("oldseat=" + '#seat-' + flNo + oldseatNo)
      document.querySelector('#seat-' + flNo + oldseatNo).classList.remove('btn-warning');//remove old seat
      // console.log("setSeat=" + '#seat-' + flNo + seatNo)
      document.querySelector('#seat-' + flNo + seatNo).classList.add('btn-warning');//add new
    } else {
      newSeatNo = addSeatForCurrentPassenger(seatForCurrentPassenger, flNo, seatForCurrentPassenger_Price)
      if (newSeatNo != false) {
        // console.log("setSeat=" + '#seat-' + flNo + newSeatNo)
        document.querySelector('#seat-' + flNo + newSeatNo).classList.add('btn-warning');
      }
    }

    // seatTaken = ""
    // document.querySelector('#seat-' + flNo + seatNo).classList.add('btn-warning');

    // // seat_takens.filter((data)=> {
    // //get value of current seatTaken by looking into ticketId
    // //this seatTaken will be used to modify its button's style

    // // seat_takens.forEach((data) => {
    // //   if (data.ticketId === currentTicketId) {
    // //     // console.log(data.ticketId === currentTicketId);
    // //     seatTaken = data.seatNo
    // //     return false;
    // //   }
    // // });


    // // do some modification with style of button
    // if (document.querySelector('#seat-' + flNo + seatTaken) != null) {

    //   // this will have multiple values
    //   if (seatTaken != seatForCurrentPassenger) {
    //     document.querySelector('#seat-' + flNo + seatTaken).classList.remove('btn-warning');
    //   }

    //   //just fix today
    //   seat_takens.filter((seat, index, arr) => {
    //     if (seat.seatNo == seatTaken) {
    //       seat_takens.splice(index, 1);
    //       // return false;
    //     }
    //   })
    //   // console.log(seat_takens.length)
    // }

    // seat_takens.push({ ticketId: currentTicketId, seatNo, seat_price: price })
    // console.log(seat_takens.length)
  } else {
    console.log("Locked this features")
  }
  //addTicketData({ticketId:id, firstName:fn, lastName:ln, email:email, phone:phone})
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////INTERACT WITH SERVER SIDE///////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Order TICKET BUTTON 
async function OrderTicket(round) {
  if (round == false)
    deleteCookie()

  // let is_no_result = false
  let selectFrom = document.querySelector('#selectFrom')[document.querySelector('#selectFrom').selectedIndex].value;
  let selectTo = document.querySelector('#selectTo')[document.querySelector('#selectTo').selectedIndex].value;
  let selectNumberOfPassenger = document.getElementById("selectNumberOfPassenger")[document.querySelector('#selectNumberOfPassenger').selectedIndex].value;

  //this should always be some value
  let dateDepart = str_trim(document.querySelector('#DateDeparure').value)
  let dateReturn = str_trim(document.querySelector('#DateReturn').value)
  console.log(dateReturn)
  let DOMflightResult = document.querySelector('#flight-result')
  DOMflightResult.classList.remove("hidden")
  if (round) {
    console.log("value for round" + round)
    selectFrom = document.querySelector('#selectTo')[document.querySelector('#selectTo').selectedIndex].value;
    selectTo = document.querySelector('#selectFrom')[document.querySelector('#selectFrom').selectedIndex].value;
    dateDepart = str_trim(document.querySelector('#DateReturn').value)
    // dateDepart = new Date(getCookieText("arrival_first_trip"))
    console.log(getCookieText("arrival_first_trip"))
    console.log(new Date(getCookieText("arrival_first_trip")))

  }


  if (selectFrom == selectTo) {
    console.log("no flight")
    DOMflightResult.innerHTML = `<div class="submit-form"><h1>NO RESULT</h1></div>`
    return;
  }

  try {

    const body = { selectFrom, selectTo, dateDepart,dateReturn, selectNumberOfPassenger };
    if (round){
      body.dateDepart = new Date(getCookieText("arrival_first_trip"))
      body.dateReturn = null
    }

    console.log("dateReturn")
    console.log(body.dateReturn)
    // if(dateReturn != null){

    // }
    console.log(body)
    const response = await fetch(`http://localhost:5000/result_fl`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })

    const returned_result = await response.json();
    console.log(returned_result)
    // if (returned_result.length==0){is_no_result=true}

    // console.log("hey")
    listFlights = ""
    temp_time_arrival = new Date()
    returned_result.map(data => {
      if (temp_time_arrival < new Date(data.scheduled_arrival))
          temp_time_arrival = new Date(data.scheduled_arrival)
      listFlights += `<div class="submit-form marginLess">
                          <div>FROM:${data.departure_airport} - TO:${data.arrival_airport} </div>  
                          <div>FROM:${convertDate(data.scheduled_departure)} - TO:${convertDate(data.scheduled_arrival)}</div>
                          <div>${data.aircraft_code} | ${data.flight_id} |  Flight_NO:${data.flight_no} | Price: ${data.fl_price}</div> 
                          <button onclick="chooseFlight('total_fl=1${dateReturn == null ? "" : "&round=true"}&pasNo=${selectNumberOfPassenger}&aircraft_code=${data.aircraft_code}&fl_no=${data.flight_no}&fl_id=${data.flight_id}&price=${data.fl_price}&from_airport=${data.departure_airport}&to_airport=${data.arrival_airport}','${temp_time_arrival}')" class="button btn-warning">Choose</button> 
                        </div>`
    })
    {/* <a href="${window.location.href}?total_fl=1&pasNo=${selectNumberOfPassenger}&aircraft_code=${data.aircraft_code}&fl_no=${data.flight_no}&fl_id=${data.flight_id}&price=${data.fl_price}" class="button btn-warning">Choose</a>   */ }



    // <button class="btn btn-warning" type="button" onclick="chooseFlight(${data.flight_id})">Choose</button>                
    // DOMflightResult.innerHTML=listFlights
    const response1 = await fetch(`http://localhost:5000/result_fl_1_connection`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })
    const returned_result1 = await response1.json();
    // console.log(returned_result1)
    temp_time_arrival = new Date()
    returned_result1.map(data => {
      if (temp_time_arrival < new Date(data.time_arrfl2))
      temp_time_arrival = new Date(data.time_arrfl2)
      listFlights += `<div class="submit-form marginLess">
                            <h5>First flight (flight number: ${data.flight1} - flight_id: ${data.flight_id_1} - aircraft_model: ${data.aircraft_code1})</h5>
                            <div>FROM:${data.depfl1} - TO:${data.arrfl1} </div>  
                            <div>FROM:${convertDate(data.time_depfl1)} - TO:${convertDate(data.time_arrfl1)}</div>
                            <h5>Second flight (flight number: ${data.flight2} - flight_id: ${data.flight_id_2} - aircraft_model: ${data.aircraft_code2})</h5>
                            <div>FROM:${data.depfl2} - TO:${data.arrfl2} </div>  
                            <div>FROM:${convertDate(data.time_depfl2)} - TO:${convertDate(data.time_arrfl2)}</div>
                            <div>PRICE: $ ${(parseFloat(data.fl_price))}</div>
                            <button onclick="chooseFlight('total_fl=2${dateReturn == null ? "" : "&round=true"}&current_fl=1&pasNo=${selectNumberOfPassenger}&aircraft_code=${data.aircraft_code1},${data.aircraft_code2}&fl_no=${data.flight1},${data.flight2}&fl_id=${data.flight_id_1},${data.flight_id_2}&price=${data.fl_price}&from_airport=${data.depfl1 + "," + data.depfl2}&to_airport=${data.arrfl1 + "," + data.arrfl2}','${temp_time_arrival}')" class="button btn-warning">Choose</button> 
                        </div>`
    
    

    })
    {/* <a href="${window.location.href}?total_fl=2&pasNo=${selectNumberOfPassenger}&aircraft_code1=${data.aircraft_code1}&aircraft_code2=${data.aircraft_code2}&fl_no1=${data.flight1}&fl_id1=${data.flight_id_1}&fl_no2=${data.flight2}&fl_id2=${data.flight_id_2}&price=${data.fl_price}" 
                            class="button btn-warning">Choose</a>   */}

    const response2 = await fetch(`http://localhost:5000/result_fl_2_connection`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })
    const returned_result2 = await response2.json();
    temp_time_arrival = new Date()
    returned_result2.map(data => {
      if (temp_time_arrival < new Date(data.time_arrfl3))
      temp_time_arrival = new Date(data.time_arrfl3)
      listFlights += `<div class="submit-form marginLess">
                            <h5>First flight (flight number: ${data.flight1} - flight_id: ${data.flight_id_1} - aircraft_model: ${data.aircraft_code1})</h5>
                            <div>FROM:${data.depfl1} - TO:${data.arrfl1} </div>  
                            <div>FROM:${convertDate(data.time_depfl1)} - TO:${convertDate(data.time_arrfl1)}</div>
                            
                            <h5>Second flight (flight number: ${data.flight2} - flight_id: ${data.flight_id_2} - aircraft_model: ${data.aircraft_code2})</h5>
                            <div>FROM:${data.depfl2} - TO:${data.arrfl2} </div>  
                            <div>FROM:${convertDate(data.time_depfl2)} - TO:${convertDate(data.time_arrfl2)}</div>
                            
                            <h5>Third flight (flight number: ${data.flight3} - flight_id: ${data.flight_id_3} - aircraft_model: ${data.aircraft_code3})</h5>
                            <div>FROM:${data.depfl3} - TO:${data.arrfl3} </div>  
                            <div>FROM:${convertDate(data.time_depfl3)} - TO:${convertDate(data.time_arrfl3)}</div>

                            <div>PRICE: $ ${(parseFloat(data.fl_price))}</div>
                            <button onclick="chooseFlight('total_fl=3${dateReturn == null ? "" : "&round=true"}&current_fl=1&pasNo=${selectNumberOfPassenger}&aircraft_code=${data.aircraft_code1},${data.aircraft_code2},${data.aircraft_code3}&fl_no=${data.flight1},${data.flight2},${data.flight3}&fl_id=${data.flight_id_1},${data.flight_id_2},${data.flight_id_3}&price=${data.fl_price}&from_airport=${data.depfl1 + "," + data.depfl2 + "," + data.depfl3}&to_airport=${data.arrfl1 + "," + data.arrfl2 + "," + data.arrfl3}','${temp_time_arrival}')" class="button btn-warning">Choose</button> 
                        </div>`
    })
    {/* <a href="${window.location.href}?total_fl=3${dateReturn == null ? "" : "&round=true"}&current_fl=1&pasNo=${selectNumberOfPassenger}&aircraft_code1=${data.aircraft_code1}&aircraft_code2=${data.aircraft_code2}&aircraft_code3=${data.aircraft_code3}&fl_no1=${data.flight1}&fl_id1=${data.flight_id_1}&fl_no2=${data.flight2}&fl_id2=${data.flight_id_2}&fl_no3=${data.flight3}&fl_id3=${data.flight_id_3}&price=${data.fl_price}&from_airport=${data.depfl1 + "," + data.depfl2 + "," + data.depfl3}&to_airport=${data.arrfl1 + "," + data.arrfl2 + "," + data.arrfl3}')"  */ }
    // class="button btn-warning">Choose</a>  
    if (listFlights.length == 0) { listFlights = `<div class="submit-form"><h1>NO RESULT</h1></div>` }
    DOMflightResult.innerHTML = listFlights
    // console.log(returned_result)
  } catch (err) {
    console.log(err.message);
    document.getElementById("message-box").classList.remove("hidden")
    document.getElementById("message-content").innerHTML = err.message;
    document.getElementById("div-error-message").classList.remove("hidden")
    document.getElementById("div-error-message").innerHTML = err.message;
  }
}
// ULTIL FUNCTIONS

function str_trim(str) {
  str = str.trim()
  if (str.length < 1)
    return null;
  return str
}

function convertDate(date) {
  D = new Date(date)
  // D=Date.parse(date)
  return (D.getMonth() + 1) + "-" + D.getDate() + "-" + D.getFullYear() + " at " + D.getHours() + ":" + D.getMinutes()
}
function getUUIDLength(length) {
  return uuidv4().replace('-', '').substr(0, length).trim()
}
function getUUID() {
  return uuidv4().substr(0, 9).trim()
}
function getUUID_Ticket() {
  return getUUIDLength(12)
}
function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function fareConditionColor(fare) {
  style = ""
  if (fare == "Business")
    style = "background-color:cadetblue;"
  else if (fare == "Comfort")
    style = "background-color:dodgerblue;"
  return style
}
//////////////////////////////////////

async function getBooking() {
  if (maxPassenger > 0) {
    try {
      const body = { pas_no: maxPassenger };
      const response = await fetch(`http://localhost:5000/get_bookings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      })
      const jsonData = await response.json();
      console.log("receive book_ref:" + jsonData)
      setBook_ref(jsonData)

    } catch (err) {
      console.log(err.message);
      document.getElementById("message-box").classList.remove("hidden")
      document.getElementById("message-content").innerHTML = err.message;
      document.getElementById("div-error-message").classList.remove("hidden")
      document.getElementById("div-error-message").innerHTML = err.message;
    }
  }
}

async function PreFinalize() {
  try {
    console.log("send data to finalize with server with book_ref" + book_ref)

    const body = { book_ref, pas_no: maxPassenger, tickets, flights, payment: glo_payment };
    const response = await fetch(`http://localhost:5000/PreFinalize`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    })

    const jsonData = await response.json();
    console.log(jsonData)
    if (jsonData.error !== null) {
      if (jsonData.message.search("boarding_passes_pkey") > -1) {
        document.getElementById("div-error-message").innerHTML = "Seat has been taken (ticketId problem is:" + jsonData.error + ")";

      } else {
        document.getElementById("div-error-message").innerHTML = jsonData.message;
      }
      document.getElementById("div-error-message").classList.remove("hidden")

    } else {
      //In PreFinalize
      location.href = "/?confirmation=true&book_ref=" + book_ref


    }

  } catch (err) {
    console.log("error code:" + err.message);
    document.getElementById("message-box").classList.remove("hidden")
    document.getElementById("message-content").innerHTML = err.message;
    document.getElementById("div-error-message").classList.remove("hidden")
    document.getElementById("div-error-message").innerHTML = err.message;
  }
}

// async function AddPassenger() {
//   try {
//     const body = { pas_no: maxPassenger, tickets };
//     const response = await fetch(`http://localhost:5000/add_passenger`, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(body)
//     })
//     const jsonData = await response.json();
//     console.log(jsonData)
//     setPassengerInTicket(jsonData)
//     
//   } catch (err) {
//     console.log(err.message);
//     document.getElementById("message-box").classList.remove("hidden")
//     document.getElementById("message-content").innerHTML = err.message;
//     document.getElementById("div-error-message").classList.remove("hidden")
//     document.getElementById("div-error-message").innerHTML = err.message;
//   }
// }

function setPassengerInTicket(passengerData) {
  console.log("add passengerId")
  data = null
  tickets.filter((ticket, i) => {
    // passengerData.forEach(data => {
    for (pi = 0; pi < passengerData.length; pi++) {
      data = passengerData[pi]
      if (data.last_name === ticket.lastName &&
        data.first_name === ticket.firstName &&
        data.phone === ticket.phone &&
        data.email === ticket.email) {
        tickets[i].passengerId = data.passengerid
        console.log(data.passengerid)
        return false;
      }
    }
  })
  console.log(tickets)
}



// displayConfirmation(book_ref)
//////////////////////////////////////////////////////////


async function displayConfirmation(book_ref) {
  //const book_ref = document.getElementById("book_ref").value;
  const body = { book_ref };

  const response = await fetch(`http://localhost:5000/confirm`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })

  const returned_result = await response.json();
  console.log(returned_result)
  let confirmticket = ""
  let displayed_ticket_no = ""
  let countTrip = 0
  returned_result.map(data => {
    if (data.ticket_no !== displayed_ticket_no) {
      countTrip += 1
      displayed_ticket_no = data.ticket_no
      confirmticket += `<div class="submit-form marginLess"> 
                          <h3 class="hidden"> Trip ${countTrip}</h3>
                          <h4 class="info">Booking Reference: ${data.book_ref}</h4>
                          <h4 class="info">Ticket No: ${data.ticket_no}</h4>
                          <h4 class="info">Booking Date: ${new Date(data.book_date).toDateString()}</h4>
                          ${data.isinwaitlist == true ? "<h4 class='info' style='color:red'>You are in wait list </h4>":""}
                          
                          
                          <div class="info">Last Name: ${data.last_name}</div>
                      <div class="info">First Name: ${data.first_name}</div>
                      <div class="info">Movie : ${data.movie == false ? "Declined" : "Included"}</div>
                      <div class="info">Meal : ${data.meal ? "Declined" : "Included"}</div>
                      <div class="info">Total Cost: $${data.amount}</div>
                      </div>`
    }
    confirmticket += `
                    <div class="submit-form marginLess">
                      <br/>
                      <div class="info">Seat No.: ${data.seat_no}</div>
                      <div class="info">Flight ID: ${data.flight_id}</div>
                      <div class="info">Scheduled Departure: ${new Date(data.scheduled_departure).toDateString()}</div>
                      <div class="info">Scheduled Arrival: ${new Date(data.scheduled_arrival).toDateString()}</div>
                      <div class="info">Departure Airport: ${data.departure_airport}</div>
                      <div class="info">Arrival Airport: ${data.arrival_airport}</div>
                      </div>
                      `;
  })
  //location.href = "/confirm.html"

  let DOMSearchBox = document.querySelector('#searchBox')
  DOMSearchBox.classList.add("hidden")

  DOMFlightInfo = document.querySelector('#flight-result')
  DOMFlightInfo.classList.remove("hidden")
  DOMFlightInfo.innerHTML = confirmticket
}

/////////////////////

// this thing to load up page 2 for passengers
if (urlParams.has('confirmation') && urlParams.has('book_ref')) {
  book_ref = urlParams.get('book_ref')
  displayConfirmation(book_ref)
}
if (urlParams.has('pasNo') && urlParams.has('total_fl') && urlParams.has('price')) {
  total_fl_id = (urlParams.get('fl_id')).split(',').length

  let local_prices = urlParams.get('price').split(',')
  local_prices.forEach((price) => {
    fl_price += parseFloat(price)
  })

  maxPassenger = urlParams.get('pasNo')
  total_fl = urlParams.get('total_fl')

  urlParams.get('fl_id').split(',').forEach((data) => {
    flights.push({ fl_id: data })
  })


  // book_ref here
  getBooking()

  console.log("max passenger:" + maxPassenger)
  urlParams.get('fl_id').split(',').forEach((flightId) => {
    loadSeatAvalability(flightId)
  })

  loadingFlightDetails("", "")


  if (total_fl_id == 2) {
    console.log("in total flight id = 2")
    current_fl_id = urlParams.get('fl_id').split(',')[0]

    console.log("ya here congrats!")

    console.log(urlParams.get('fl_id'))
    console.log(urlParams.get('pasNo'))

    numberOfPassenger = urlParams.get('pasNo')

    DOMSearchBox = document.querySelector('#searchBox')
    DOMPassengerBox = document.querySelector('#passengerBox')
    DOMselectNumberOfPassenger = document.getElementById("selectNumberOfPassenger");
    DOMSearchBox.classList.add("hidden")
    DOMPassengerBox.classList.remove("hidden")

  }
  else if (total_fl_id == 3) {
    console.log("in total flight id = 3")
    loadingFlightDetails(urlParams.get('from_airport').split(','), urlParams.get('to_airport').split(','))
    current_fl_id = urlParams.get('fl_id').split(',')[0]

    console.log("ya here congrats! 2222")
    console.log(urlParams.get('pasNo'))
    numberOfPassenger = urlParams.get('pasNo')


    DOMSearchBox = document.querySelector('#searchBox')
    DOMPassengerBox = document.querySelector('#passengerBox')
    DOMselectNumberOfPassenger = document.getElementById("selectNumberOfPassenger");
    DOMSearchBox.classList.add("hidden")
    DOMPassengerBox.classList.remove("hidden")

  }
  else if (total_fl_id == 1) {
    console.log("in total flight id = 1")
    // loadingFlightDetails(urlParams.get('from_airport').split(','), urlParams.get('to_airport').split(','))
    current_fl_id = urlParams.get('fl_id')
    console.log(urlParams.get('fl_no'))
    console.log(urlParams.get('fl_id'))
    console.log(urlParams.get('pasNo'))
    // flights.push({ fl_id: urlParams.get('fl_id') })

    //hidden the check list
    // show the flight stuff
    numberOfPassenger = urlParams.get('pasNo')

    DOMSearchBox = document.querySelector('#searchBox')
    DOMPassengerBox = document.querySelector('#passengerBox')
    DOMselectNumberOfPassenger = document.getElementById("selectNumberOfPassenger");
    DOMSearchBox.classList.add("hidden")
    DOMPassengerBox.classList.remove("hidden")

  }
  else {
    // for NON-first time in page
    console.log("greater than 3")

    console.log("in total flight id = " + total_fl_id)
    // loadingFlightDetails(urlParams.get('from_airport').split(','), urlParams.get('to_airport').split(','))
    current_fl_id = urlParams.get('fl_id')
    console.log(urlParams.get('fl_no'))
    console.log(urlParams.get('fl_id'))
    console.log(urlParams.get('pasNo'))

    numberOfPassenger = urlParams.get('pasNo')

    DOMSearchBox = document.querySelector('#searchBox')
    DOMPassengerBox = document.querySelector('#passengerBox')
    DOMselectNumberOfPassenger = document.getElementById("selectNumberOfPassenger");
    DOMSearchBox.classList.add("hidden")
    DOMPassengerBox.classList.remove("hidden")

  }

  if (currentTicketId == "") {
    currentTicketId = getUUID_Ticket()
    console.log("init ticketID")
  }
}// if nothing on top, then just loading data
else {
  loadingData();
  deleteCookie()
}

