// CREATE TABLE todo(
//   todo_id SERIAL PRIMARY KEY,
//   description VARCHAR(255)  
// );
// only two attributes in the table: todo_id and description
const Pool = require('pg').Pool;

const pool = new Pool({
  host: 'code.cs.uh.edu',
  user: 'coscxxxx',
  password: 'yourpassword',
  port: 5432,
  database: 'COSC3380'
  // host: 'ec2-52-44-139-108.compute-1.amazonaws.com',
  // user: 'vewdgrbwwhymgt',
  // password: '6030ab659305a7c6a2a584b67143828ec20cdf5d1ebb244baab676b99324d644',
  // port: 5432,
  // database: 'd35uq8dd35ol0m'
});
module.exports = pool;
