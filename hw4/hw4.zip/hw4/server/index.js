const express = require('express');
const app = express();
const cors = require('cors');
const pool = require('./db');
const async = require("async");
fs = require('fs');

const schema = "a3gs7d"
//or 
//const schema = "coscxxxx" xxxx = your Linux account ID
const writeSQLNormal = async (data) => {
  await fs.appendFile("query.sql", data, function (err) {
    if (err) return console.log(err);
    console.log('finished');
  })
}

const writeSQLTransaction = async (data) => {
  await fs.appendFile("transaction.sql", data, function (err) {
    if (err) return console.log(err);
    console.log('finished');
  })
}

// middleware
app.use(cors());
app.use(express.json());      //req.body

function getUUIDLength(length) {
  return uuidv4().replace('-', '').substr(0, length).trim()
}
function getUUID() {
  return uuidv4().substr(0, 6).trim()
}
function getUUIDBaggageNo() {
  return getUUIDLength(10)
}
function getUUID_Bookref() {
  return getUUIDLength(9)
}

function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}
//ROUTES

// app.get('/s1', async (req, res) => {
//   try {
//     var book_ref = getUUID_Bookref()
//     const newTodo = await pool.query(`INSERT INTO todo (description) VALUES($1) RETURNING *`
//     );
//     console.log(newTodo)
//     res.json(newTodo);
//   } catch (err) {
//     console.log(err.message);
//   }
// });

// //insert a todo
// app.post('/todos', async (req, res) => {
//   try {
//     const { description } = req.body;
//     const newTodo = await pool.query(`INSERT INTO todo (description) VALUES(0) RETURNING description`,
//       [description]);
//     console.log(newTodo)
//     res.json(newTodo);
//   } catch (err) {
//     console.log(err.message);
//   }
// });

// //get all todo
// app.get('/todos', async (req, res) => {
//   try {
//     const allTodos = await pool.query(`SELECT * FROM todo`);
//     res.json(allTodos.rows);
//   } catch (err) {
//     console.log(err.message);
//   }
// });

//get all todo
app.get('/fl_from', async (req, res) => {
  try {
    console.log("request to fl_from");
    const query = `SELECT * FROM ${schema}.airports ORDER BY airport_name`
    writeSQLNormal(query)
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});

//get all todo
app.get('/fl_to', async (req, res) => {
  try {
    console.log("request to fl_to");
    const query = `SELECT * FROM ${schema}.airports ORDER BY airport_name`
    writeSQLNormal(query)
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});



app.post('/get_price', async (req, res) => {
  try {
    //body {selectFrom,selectTo, dateDepart, dateReturn}
    console.log("get price");
    console.log(req.body)
    const { flight_id } = req.body;
    const query = `SELECT fl_price from ${schema}.flights where flight_id=$1`
    writeSQLNormal(query)
    const result = await pool.query(query, [flight_id]);
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});


app.post('/result_fl', async (req, res) => {
  try {
    //body {selectFrom,selectTo, dateDepart, dateReturn}
    console.log("result_fl");
    console.log(req.body)
    const { selectFrom, selectTo, dateDepart, dateReturn, selectNumberOfPassenger } = req.body;
    console.log({ selectFrom, selectTo, dateDepart, dateReturn, selectNumberOfPassenger })
    var query = ""

    console.log(dateDepart)
    console.log(dateReturn)
    if (dateReturn != null) {
      query = `SELECT * FROM ${schema}.flights WHERE departure_airport = $1 AND 
      arrival_airport = $2 AND scheduled_departure >= $3 AND scheduled_arrival <= $5
      AND (seats_available+waitlist_available-$4) >=0`

    } else {
      query = `SELECT * FROM ${schema}.flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0`
    }

    writeSQLNormal(query)

    if (dateReturn != null) {
      await pool.query(query,
        [selectFrom, selectTo, dateDepart, selectNumberOfPassenger, dateReturn]).then(result => {
          console.log("result flight=" + result.rows.length)
          res.json(result.rows);
        });;
    } else {
      await pool.query(query,
        [selectFrom, selectTo, dateDepart, selectNumberOfPassenger]).then(result => {
          console.log("result flight=" + result.rows.length)
          res.json(result.rows);
        });
    }

    // console.log("result flight=" + result.rows.length)
    // res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});


app.post('/result_fl_1_connection', async (req, res) => {
  try {
    //body {selectFrom,selectTo, dateDepart, dateReturn}
    console.log("result_fl_1_connection");
    console.log(req.body)
    const { selectFrom, selectTo, dateDepart, dateReturn, selectNumberOfPassenger } = req.body;
    var query = ""

    console.log(dateDepart)
    console.log(dateReturn)

    if (dateReturn != null) {
      query = `SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

          FROM ${schema}.flights fl1
          INNER JOIN ${schema}.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
          AND fl1.arrival_airport NOT LIKE $2 
          AND fl2.departure_airport NOT LIKE $1 
          AND fl1.arrival_airport  = fl2.departure_airport 
          AND fl2.scheduled_departure > fl1.scheduled_arrival

          WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 
          AND fl2.scheduled_arrival <= $5
          AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
          AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
`
    }
    else {
      query = `SELECT  
        (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

        fl1.scheduled_departure as "time_depfl1",
        fl1.scheduled_arrival as "time_arrfl1",
        fl1.departure_airport as "depfl1",
        fl1.arrival_airport as "arrfl1",

        fl2.scheduled_departure as "time_depfl2",
        fl2.scheduled_arrival as "time_arrfl2",
        fl2.departure_airport as "depfl2",
        fl2.arrival_airport as "arrfl2",

        fl1.flight_id as flight_id_1,
        fl1.flight_no as flight1,
        fl2.flight_id as flight_id_2,
        fl2.flight_no as flight2,
        fl1.aircraft_code as "aircraft_code1",
        fl2.aircraft_code as "aircraft_code2"

        FROM ${schema}.flights fl1
        INNER JOIN ${schema}.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
        AND fl1.arrival_airport NOT LIKE $2 
        AND fl2.departure_airport NOT LIKE $1 
        AND fl1.arrival_airport  = fl2.departure_airport 
        AND fl2.scheduled_departure > fl1.scheduled_arrival

        WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 
        AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
        AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
        `}
    writeSQLNormal(query);

    if (dateReturn != null) {
      await pool.query(query,
        [selectFrom, selectTo, dateDepart, selectNumberOfPassenger, dateReturn]).then(result => {
          console.log("result flight=" + result.rows.length)
          res.json(result.rows);
        });;
    } else {
      await pool.query(query,
        [selectFrom, selectTo, dateDepart, selectNumberOfPassenger]).then(result => {
          console.log("result flight=" + result.rows.length)
          res.json(result.rows);
        });
    }
    // const result = await pool.query(query, [selectFrom, selectTo, dateDepart, selectNumberOfPassenger]);
    // console.log("result flight=" + result.rows.length)
    // res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});


app.post('/result_fl_2_connection', async (req, res) => {
  try {
    //body {selectFrom,selectTo, dateDepart, dateReturn}
    console.log("result_fl_2connect");
    console.log(req.body)
    const { selectFrom, selectTo, dateDepart, dateReturn, selectNumberOfPassenger } = req.body;
    var query = ""
    console.log(dateDepart)
    console.log(dateReturn)
    if (dateReturn != null) {
      query = `
    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM ${schema}.flights fl1
    INNER JOIN ${schema}.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN ${schema}.flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 AND fl3.scheduled_departure > $3
    AND fl3.scheduled_arrival <= $5
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    `
    } else {
      query = `
    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM ${schema}.flights fl1
    INNER JOIN ${schema}.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN ${schema}.flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 AND fl3.scheduled_departure > $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    `
    }
    writeSQLNormal(query)
    if (dateReturn != null) {
      await pool.query(query,
        [selectFrom, selectTo, dateDepart, selectNumberOfPassenger, dateReturn]).then(result => {
          console.log("result flight=" + result.rows.length)
          console.log(dateDepart)
          console.log(dateReturn)
          res.json(result.rows);
        });;
    } else {
      await pool.query(query,
        [selectFrom, selectTo, dateDepart, selectNumberOfPassenger]).then(result => {
          console.log("result flight=" + result.rows.length)
          res.json(result.rows);
        });
    }
    // const result = await pool.query(query, [selectFrom, selectTo, dateDepart, selectNumberOfPassenger]);
    // console.log("result flight=" + result.rows.length)
    // res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});

// app.post('/receipt_details', async (req, res) => {

//   `select tf.flight_id,tf.seat_no, scn.fare_conditions, scn.fare_price from ticket_flights tf
// INNER JOIN aircraft_seats ast ON tf.seat_no= ast.seat_no AND tf.flight_id=ast.flight_id
// INNER JOIN seatConditions scn ON scn.fare_id = ast.fare_id;
// `
// })



app.post('/update_flight', async (req, res) => {
  try {


    const { flight_id, seat_available, seat_booked, waitList, price, timeDepart, timeArrive, airport_depart, airport_arrive } = req.body
    console.log({ flight_id, seat_available, seat_booked, waitList, price })
    // const { flight_id } = req.body;
    console.log("update_flight");
    console.log({ flight_id, seat_available, seat_booked, waitList, price, timeDepart, timeArrive, airport_depart, airport_arrive })
    const query = `UPDATE ${schema}.flights SET waitlist_available = $1, 
                                            seats_booked = $2, seats_available= $3,fl_price = $4,
                                            scheduled_departure = $6, scheduled_arrival = $7, 
                                            departure_airport = $8, arrival_airport = $9
                                            where flight_id = $5`
    writeSQLNormal(query);
    const result = await pool.query(query, [waitList, seat_booked, seat_available, price, flight_id, new Date(timeDepart), new Date(timeArrive), airport_depart, airport_arrive]);
    res.status(200).json(result.rows);
  } catch (err) {
    console.log(err.message);
    res.status(500).json(err.message);
  }

})
app.get('/get_flights_staff', async (req, res) => {
  try {

    console.log(req.body)
    // const { flight_id } = req.body;
    console.log("get_flights_staff");

    returnResult = {}
    const query = `Select *, a.airline_name from ${schema}.flights f 
    INNER JOIN ${schema}.airlines a ON f.airline_id = a.airline_id 
    ORDER BY flight_id;
    `
    writeSQLNormal(query);
    const result = await pool.query(query, []);

    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }


})

app.post('/seat_available', async (req, res) => {

  try {

    console.log(req.body)
    const { flight_id } = req.body;
    console.log("seat_available for flight:" + flight_id);

    returnResult = {}
    const query = `
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM ${schema}.aircraft_seats ast
                    INNER JOIN ${schema}.seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ${schema}.ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                `
    writeSQLNormal(query);
    const result = await pool.query(query, [flight_id]);
    returnResult = result.rows
    // console.log(returnResult)
    res.json(returnResult);

  } catch (err) {
    console.log(err.message);
  }
});

// set up the server listening at port 5000 (the port number can be changed)
app.listen(5000, () => {
  console.log("server has started on port 5000");
});

app.post('/get_bookings', async (req, res) => {
  try {
    returnValue = ""
    console.log("get_bookings");
    console.log(req.body)
    var book_ref = getUUID_Bookref()
    console.log("book_ref is:" + book_ref)
    const { pas_no } = req.body;
    const query = `
                  INSERT INTO ${schema}.bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *`
    writeSQLNormal(query);


    const result = await pool.query(query,
      [book_ref, pas_no]);
    console.log(result.rows)
    res.json(result.rows[0].book_ref);
  } catch (err) {
    console.log(err.message);
  }
});



// app.post('/add_passenger', async (req, res) => {
//   try {
//     returnValue = ""
//     console.log("add_passenger");
//     console.log(req.body)
//     const { tickets } = req.body;
//     var result = null
//     insertPassenger = "";
//     value = []
//     ticket = null


//     for (let index = 0; index < tickets.length; index++) {
//       ticket = tickets[index]
//       insertPassenger = `INSERT INTO passengers(last_name,first_name, email, phone) 
//                            VALUES ($1,$2,$3,$4)
//                            RETURNING *;`

//       writeSQL(insertPassenger);
//       result = await pool.query(insertPassenger,
//         [ticket.lastName, ticket.firstName, ticket.email, ticket.phone])
//       value.push(result.rows[0])
//     }
//     console.log(value)
//     res.json(value);

//   } catch (err) {
//     console.log(err.message);
//   }
// });


function rollback(client) {
  console.log("rollback")
  client.query('ROLLBACK', function () {
    client.end();
  });
}

/*
DELETE FROM boarding_passes;
DELETE FROM tickets;
*/
app.post('/confirm', async (req, res) => {
  //display refund results
  try {
    console.log("confirm ............");
    console.log(req.body)
    const { book_ref } = req.body;
    const result = await pool.query(`
    SELECT tickets.ticket_no, bookings.book_ref, tickets.isInWaitList, tickets.amount, ticket_flights.seat_no, flights.flight_id, ticket_flights.seat_no,
        passengers.last_name, passengers.first_name, boarding_passes.meal, boarding_passes.movie, bookings.book_date,
        flights.flight_id, flights.departure_airport, flights.arrival_airport, flights.scheduled_departure, flights.scheduled_arrival
    FROM ${schema}.bookings
    INNER JOIN ${schema}.tickets ON tickets.book_ref = bookings.book_ref
    INNER JOIN ${schema}.ticket_flights ON ticket_flights.ticket_no = tickets.ticket_no
    INNER JOIN ${schema}.flights ON flights.flight_id  = ticket_flights.flight_id
    INNER JOIN ${schema}.passengers ON tickets.passengerId = passengers.passengerId
    INNER JOIN ${schema}.boarding_passes ON boarding_passes.ticket_no = tickets.ticket_no AND flights.flight_id  = boarding_passes.flight_id
    WHERE bookings.book_ref = $1
    ORDER BY tickets.ticket_no,flights.scheduled_departure `, [book_ref]);
    console.log(result.rows)
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});

app.post('/result_boarding_pass', async (req, res) => {
  //display boarding_pass
  try {
    console.log("result_boarding_pass");
    console.log(req.body)
    const { lastname, firstname, ticket_no } = req.body;

    const result = await pool.query(`SELECT DISTINCT passengers.passengerId, passengers.last_name, passengers.first_name, 
    tickets.ticket_no, ticket_flights.seat_no,flights.flight_id, flights.flight_no, flights.departure_airport, 
    flights.arrival_airport, flights.gatecode_depart, flights.gatecode_arrival, boarding_passes.baggage_claim_no,flights.scheduled_departure
    FROM ${schema}.passengers 
    JOIN ${schema}.tickets ON passengers.passengerId = tickets.passengerId
    JOIN ${schema}.ticket_flights ON tickets.ticket_no = ticket_flights.ticket_no 
    JOIN ${schema}.flights ON flights.flight_id = ticket_flights.flight_id
    JOIN ${schema}.bookings ON bookings.book_ref = tickets.book_ref
    JOIN ${schema}.boarding_passes ON boarding_passes.ticket_no = tickets.ticket_no
    WHERE tickets.ticket_no = $1 AND passengers.first_name = $2 AND passengers.last_name= $3
    ORDER BY flights.scheduled_departure`, [ticket_no, firstname, lastname]);
    console.log(result.rows)
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});

app.post('/result_waitlist', async (req, res) => {
  //display waitlist results
  try {
    console.log("result_waitlist");
    console.log(req.body)
    const { firstname, lastname, flightid, flightno, ticket_no } = req.body;
    query = `SELECT passengers.last_name,passengers.first_name,tickets.ticket_no, tickets.book_ref FROM  ${schema}.tickets 
            INNER JOIN ${schema}.passengers ON passengers.passengerid = tickets.passengerid 
            WHERE isinwaitlist = '1'`
    writeSQLNormal(query);

    const result = await pool.query(query, []);
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});

app.post('/result_refund', async (req, res) => {
  //display refund results
  try {
    console.log("result_refund");
    console.log(req.body)
    const { ticket_no } = req.body;

    query =`SELECT booking_payments.amount, booking_payments.book_ref, tickets.ticket_no
              from ${schema}.booking_payments 
              INNER JOIN ${schema}.bookings ON bookings.book_ref = booking_payments.book_ref
              INNER JOIN ${schema}.tickets ON tickets.book_ref = bookings.book_ref
              WHERE tickets.ticket_no = $1 AND booking_payments.amount <0`
    writeSQLNormal(query);
    const result = await pool.query(query,
      [ticket_no]);
    res.json(result.rows);
  } catch (err) {
    console.log(err.message);
  }
});


//Update cancellation
app.post("/cancel", (req, res) => {

  pool.connect(async (err, client, done) => {
    if (err) {
      throw err;
    }
    try {
      /*const { id } = req.params; */
      const { ticket_no, book_ref } = req.body;

      isCanceled = false
      amount = 0.00
      paymentId = 0
      isSuccess = false;
      await client.query('BEGIN', (err, result) => {
        if (err) {
          console.error(err);
          return rollback(client);
        }
      })
      query = `UPDATE ${schema}.tickets SET isCancelled = '1' WHERE ticket_no = $1 AND book_ref = $2 RETURNING *`
      writeSQLTransaction("BEGIN " + query);
      await pool.query(query,
        [ticket_no, book_ref]).then(result => {
          console.log("Update cancel went through..")
          console.log(result.rows)
          // console.log(result)
          if (result.rows <= 0) {
            // res.status(404).json("cannot find ticket");
            console.log("Nothing to update..")
          } else {
            console.log("Ticket has been cancled")
            console.log(result.rows[0])
            isCanceled = result.rows[0].iscancelled
            // res.status(200).json("Ticket has been cancled" + result.rows[0].iscancelled);
          }

        })
      if (isCanceled == true) {
        query = ` SELECT booking_payments.tax, tickets.amount, bookings.book_ref,booking_payments.paymentId 
      FROM ${schema}.bookings 
      INNER JOIN ${schema}.booking_payments ON bookings.book_ref = booking_payments.book_ref 
      INNER JOIN ${schema}.tickets ON tickets.book_ref = bookings.book_ref
      WHERE bookings.book_ref = $1 AND tickets.ticket_no = $2`
        console.log("get select")
        writeSQLTransaction(query);
        await client.query(query,
          [book_ref, ticket_no]).then(result => {
            console.log("OK select stuff success")
            if (result.rows <= 0) {
              isSuccess = false
            } else {
              console.log("Assign value into this")
              console.log(result.rows)
              amount = (parseFloat(result.rows[0].amount) * (1 + (parseFloat(result.rows[0].tax) / 100))) * (-1)
              paymentid = parseInt(result.rows[0].paymentid)
              // res.status(200).json("Ticket has been canceled, refund has been started");
            }
          })

        query = `INSERT INTO ${schema}.booking_payments(book_ref,paymentId,amount) 
        VALUES ($1,$2,$3) RETURNING *`
        console.log("INSERT REFUND")
        writeSQLTransaction(query);
        await client.query(query,
          [book_ref, paymentid, amount]).then(result => {
            console.log(result.rows)
            if (result.rows <= 0) {
              // res.status(404).json("cannot find ticket");
              console.log("ERROR: insert refund ")
              isSuccess = true
              console.log("insert refund success")
              console.log(result.rows[0])
              // res.status(200).json("Ticket has been canceled, refund has been started");
            } else { isSuccess = true }
          })
        // writeSQLTransaction(query);


      }

      if (isSuccess == false) {
        console.log("FAILED: about to ROLBACK")
        writeSQLTransaction("ROLLBACK");
        await client.query('ROLLBACK', function () {
          client.end();
        });
        res.status(404).json({ message: "This ticket has been canceled.", error: null })
      } else {
        console.log("success : about to commit")
        writeSQLTransaction("COMMIT");
        await client.query('COMMIT', client.end.bind(client));
        res.status(200).json({ message: "success! refunded and canceled", error: null })
      }
    } catch (err) {
      console.log(err.message);
      rollback(client);
      res.status(500).json({ message: "Error on serverside " + err.message, error: err.message })
    }
  });
});

//List flight info
app.post('/result_total_passengers', async (req, res) => {
  //display refund results
  try {
    console.log("result_total_passengers");
    console.log(req.body)
    const { flightid } = req.body;
    const result = await pool.query(`SELECT flights.flight_id, flights.flight_no, count(ticket_flights.ticket_no) as total_passengers
                                  FROM ${schema}.ticket_flights 
                                  INNER JOIN ${schema}.flights ON ticket_flights.flight_id = flights.flight_id
                                  WHERE flights.flight_id = $1
                                  GROUP BY flights.flight_id`, [flightid]);
    console.log(result.rows);
    res.json(result.rows);

  } catch (err) {
    console.log(err.message);
  }
});

app.post('/PreFinalize', (req, res) => {
  //https://www.wlaurance.com/2016/09/nodejs-postgresql-transactions-and-query-examples 
  //https://medium.com/@FranckPachot/transaction-management-in-postgresql-and-what-is-different-from-oracle-eeae34675a77
  //https://stackoverflow.com/questions/58174695/prevent-sql-injection-with-nodejs-and-postgres
  console.log("PreFinalize");
  // console.log(req.body)
  const { book_ref, pas_no, tickets, flights, payment } = req.body;
  console.log({ book_ref, pas_no, tickets, flights, payment })
  isSuccess = true;
  is_seat_available = true;
  // tickets = [{ticketId:'29954c', book_ref: "106eb1"},{ticketId:'73016f', book_ref: "360d67"}]
  pool.connect(async (err, client, done) => {
    if (err) {
      throw err;
    }

    try {
      var seat_amount = 0
      var total_amount = 0;
      var current_ticketId = -1
      var temp_passengerId = -1
      await client.query('BEGIN', (err, result) => {
        if (err) {
          console.error(err);
          return rollback(client);
        }
      })

      //LOOP THROUGH ALL TICKETS
      for (let index = 0; index < tickets.length; index++) {
        if (!isSuccess) break;
        is_seat_available = true
        is_seat_available_flag_for_ticket=true

        seat_amount = 0;
        total_amount = 0;
        // tickets[index].ticketId = getUUID()
        ticket = tickets[index]
        current_ticketId = ticket.ticketId
        console.log({ book_ref: book_ref, ticketId: ticket.ticketId })

        insertPassenger = `INSERT INTO ${schema}.passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;`

        writeSQLTransaction(insertPassenger);
        console.log("Adding passenger...")
        await pool.query(insertPassenger,
          [ticket.lastName, ticket.firstName, ticket.email, ticket.phone]).then(result => {
            console.log("Added success!")
            // console.log(result)
            if (result.rows <= 0) {
              
              console.log({ lastName: ticket.lastName, firstName: ticket.firstName, email: ticket.email, phone: ticket.phone })
              console.log("no passenger added:" + ticket.ticketId)
              // return;
            } else {
              ticket.passengerId = result.rows[0].passengerid
              console.log("success update passenger:" + result.rows[0].passengerid)
            }
          })

        ticket.seatNo.forEach(element => {
          seat_amount += parseFloat(element.price)
        });
        //totalAmount 
        total_amount = total_amount + ticket.amount + seat_amount
        console.log("total_amount(with seat)=" + total_amount)



        //LOOPING THROUGH FLIGHTS
        for (let fl_index = 0; fl_index < flights.length; fl_index++) {
          is_seat_available=true // reset this flag

          console.log({ fli_id: flights[fl_index].fl_id, ticketId: ticket.ticketId })
          query = `UPDATE ${schema}.flights SET seats_booked = seats_booked + 1, 
                  seats_available = seats_available - 1 WHERE flight_id=$1 AND (seats_available-1) >= 0 
                  RETURNING *`
          writeSQLTransaction(query);
          //UPDATE FLIGHTS
          await client.query(query,
            [flights[fl_index].fl_id]).then(result => {
              if (result.rows <= 0) {
                is_seat_available = false // add to waitlist
                is_seat_available_flag_for_ticket = false;
                console.log("no seat available:" + ticket.ticketId + "| flight:" + flights[fl_index].fl_id)
                // return;
              } else {
                console.log("success update flights:" + ticket.ticketId + "| flight:" + flights[fl_index].fl_id)
              }
            })

          if (!is_seat_available) {
            
            query = `UPDATE ${schema}.flights SET waitlist_available = waitlist_available - 1 
                    WHERE flight_id=$1 AND (waitlist_available-1) >= 0 RETURNING *`
            writeSQLTransaction(query);

            console.log("checking the waitlist capacity...")

            await client.query(query,
              [flights[fl_index].fl_id])
              .then(result => {
                if (result.rows <= 0) {
                  isSuccess = false // add to waitlist
                  console.log("cannot add ticket:" + ticket.ticketId + "| flight:" + flights[fl_index].fl_id)
                  // return;
                } else {
                  console.log("success add ticket:" + ticket.ticketId + "| flight:" + flights[fl_index].fl_id)
                }
              })
            //maybe update customer isWaitList?
          }
        }//END loop through FLIGHTS

        if (!isSuccess) {
          break;
          // console.log("still doing query after not success--- BUGGGG")
        }
        console.log("inwaitlist="+ (is_seat_available_flag_for_ticket==false))
        ///ADD TICKET
        query = `INSERT INTO ${schema}.tickets(ticket_no, book_ref, checked_bags_quantity,amount,passengerId, isInWaitList) 
          VALUES ($1,$2,$3,$4,$5,$6)`
        writeSQLTransaction(query);
        await client.query(query,
          [ticket.ticketId, book_ref, ticket.checked_bags_no, total_amount, ticket.passengerId, is_seat_available_flag_for_ticket==false])

        //UPDATE BOARDING_PASSES
        // await client.query(`INSERT INTO boarding_passes(ticket_no, flight_id,baggage_claim_no) VALUES ($1,$2,$3)`,
        //   [ticket.ticketId, flights[fl_index].fl_id, getUUIDBaggageNo()])

        console.log("adding boarding passes...")
        seat_list = ticket.seatNo
        temp_baggage_claim = getUUIDBaggageNo() //ticket.checked_bags_no > 0 ? getUUIDBaggageNo() : null
        for (seat_index = 0; seat_index < seat_list.length; seat_index++) {
          query = `INSERT INTO ${schema}.boarding_passes(ticket_no, flight_id,movie, meal,baggage_claim_no) 
                  VALUES ($1,$2,$3,$4,$5)`
          writeSQLTransaction(query);

          await client.query(query,
            [ticket.ticketId, seat_list[seat_index].flight_id, ticket.isMovie, ticket.isMeal,
              temp_baggage_claim])

          query = `INSERT INTO ${schema}.ticket_flights(ticket_no, flight_id, seat_no) 
                                      VALUES ($1, $2, $3);`
          writeSQLTransaction(query);
          //UPDATE TICKET_FLIGHTS
          await client.query(query,
            [ticket.ticketId, seat_list[seat_index].flight_id, seat_list[seat_index].seatNo])

        }

      }
      if (isSuccess == true) { // If it was not failed
        // ADD PAYMENT AFTER LOOPING THROUGH TICKETS
        query = `INSERT INTO ${schema}.payments(card_holder_name,card_number,CVV,Exp_Date) 
                              VALUES ($1,$2,$3,$4) RETURNING paymentId`
        writeSQLTransaction(query);
        const value = await client.query(query,
          [payment.cardHolder, payment.cardNumber, payment.CVV, payment.EXP])

        console.log("paymentid is:" + value.rows[0].paymentid)


        query = `INSERT INTO ${schema}.booking_payments(book_ref,paymentId,amount) 
                                        VALUES ($1,$2,$3)`
        writeSQLTransaction(query);

        await client.query(query,
          [book_ref, value.rows[0].paymentid, payment.amount])
      }

      if (isSuccess == false) {
        console.log("FAILED: about to ROLBACK")
        writeSQLTransaction("ROLLBACK");
        await client.query('ROLLBACK', function () {
          client.end();
        });
      } else {
        console.log("success : about to commit")
        writeSQLTransaction("COMMIT");
        await client.query('COMMIT', client.end.bind(client));
      }
      res.status(200).json({ message: "success! everything is ready1", error: null })
    } catch (err) {
      console.log(err.message);
      rollback(client);
      res.status(500).json({ message: "Error on serverside " + err.message, error: current_ticketId })
    }
  });
});



