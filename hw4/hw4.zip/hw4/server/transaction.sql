SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                           VALUES ($1,$2,$3,$4)
                           RETURNING *;INSERT INTO passengers(last_name,first_name, email, phone) 
                           VALUES ($1,$2,$3,$4)
                           RETURNING *;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                           VALUES ($1,$2,$3,$4)
                           RETURNING *;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameINSERT INTO a3gs7d.passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;UPDATE a3gs7d.flights SET seats_booked = seats_booked + 1, 
                  seats_available = seats_available - 1 WHERE flight_id=$1 AND (seats_available-1) >= 0 
                  RETURNING *UPDATE a3gs7d.flights SET seats_booked = seats_booked + 1, 
                  seats_available = seats_available - 1 WHERE flight_id=$1 AND (seats_available-1) >= 0 
                  RETURNING *UPDATE a3gs7d.flights SET seats_booked = seats_booked + 1, 
                  seats_available = seats_available - 1 WHERE flight_id=$1 AND (seats_available-1) >= 0 
                  RETURNING *UPDATE a3gs7d.flights SET seats_booked = seats_booked + 1, 
                  seats_available = seats_available - 1 WHERE flight_id=$1 AND (seats_available-1) >= 0 
                  RETURNING *INSERT INTO a3gs7d.tickets(ticket_no, book_ref, checked_bags_quantity,amount,passengerId, isInWaitList) 
          VALUES ($1,$2,$3,$4,$5,$6)INSERT INTO a3gs7d.boarding_passes(ticket_no, flight_id,movie, meal,baggage_claim_no) 
                  VALUES ($1,$2,$3,$4,$5)INSERT INTO a3gs7d.ticket_flights(ticket_no, flight_id, seat_no) 
                                      VALUES ($1, $2, $3);INSERT INTO a3gs7d.boarding_passes(ticket_no, flight_id,movie, meal,baggage_claim_no) 
                  VALUES ($1,$2,$3,$4,$5)INSERT INTO a3gs7d.ticket_flights(ticket_no, flight_id, seat_no) 
                                      VALUES ($1, $2, $3);INSERT INTO a3gs7d.boarding_passes(ticket_no, flight_id,movie, meal,baggage_claim_no) 
                  VALUES ($1,$2,$3,$4,$5)INSERT INTO a3gs7d.ticket_flights(ticket_no, flight_id, seat_no) 
                                      VALUES ($1, $2, $3);INSERT INTO a3gs7d.boarding_passes(ticket_no, flight_id,movie, meal,baggage_claim_no) 
                  VALUES ($1,$2,$3,$4,$5)INSERT INTO a3gs7d.ticket_flights(ticket_no, flight_id, seat_no) 
                                      VALUES ($1, $2, $3);INSERT INTO a3gs7d.payments(card_holder_name,card_number,CVV,Exp_Date) 
                              VALUES ($1,$2,$3,$4) RETURNING paymentIdINSERT INTO a3gs7d.booking_payments(book_ref,paymentId,amount) 
                                        VALUES ($1,$2,$3)COMMITBEGIN UPDATE a3gs7d.tickets SET isCancelled = '1' WHERE ticket_no = $1 AND book_ref = $2 RETURNING * SELECT booking_payments.tax, tickets.amount, bookings.book_ref,booking_payments.paymentId 
      FROM a3gs7d.bookings 
      INNER JOIN a3gs7d.booking_payments ON bookings.book_ref = booking_payments.book_ref 
      INNER JOIN a3gs7d.tickets ON tickets.book_ref = bookings.book_ref
      WHERE bookings.book_ref = $1 AND tickets.ticket_no = $2INSERT INTO a3gs7d.booking_payments(book_ref,paymentId,amount) 
        VALUES ($1,$2,$3) RETURNING *COMMIT