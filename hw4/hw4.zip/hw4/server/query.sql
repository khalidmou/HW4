SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                           VALUES ($1,$2,$3,$4)
                           RETURNING *;INSERT INTO passengers(last_name,first_name, email, phone) 
                           VALUES ($1,$2,$3,$4)
                           RETURNING *;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                           VALUES ($1,$2,$3,$4)
                           RETURNING *;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1 
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM flights fl1
    INNER JOIN flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM aircraft_seats ast
                    INNER JOIN seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;INSERT INTO passengers(last_name,first_name, email, phone) 
                               VALUES ($1,$2,$3,$4)
                               RETURNING passengerId;SELECT * FROM airports ORDER BY airport_nameSELECT * FROM airports ORDER BY airport_nameSELECT * FROM a3gs7d.airports ORDER BY airport_nameSELECT * FROM a3gs7d.airports ORDER BY airport_nameSELECT * FROM a3gs7d.flights WHERE departure_airport = $1 AND 
      arrival_airport = $2 AND scheduled_departure >= $3 AND scheduled_arrival <= $5
      AND (seats_available+waitlist_available-$4) >=0SELECT  
            (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

            fl1.scheduled_departure as "time_depfl1",
            fl1.scheduled_arrival as "time_arrfl1",
            fl1.departure_airport as "depfl1",
            fl1.arrival_airport as "arrfl1",
    
            fl2.scheduled_departure as "time_depfl2",
            fl2.scheduled_arrival as "time_arrfl2",
            fl2.departure_airport as "depfl2",
            fl2.arrival_airport as "arrfl2",

            fl1.flight_id as flight_id_1,
            fl1.flight_no as flight1,
            fl2.flight_id as flight_id_2,
            fl2.flight_no as flight2,
            fl1.aircraft_code as "aircraft_code1",
            fl2.aircraft_code as "aircraft_code2"

          FROM a3gs7d.flights fl1
          INNER JOIN a3gs7d.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
          AND fl1.arrival_airport NOT LIKE $2 
          AND fl2.departure_airport NOT LIKE $1 
          AND fl1.arrival_airport  = fl2.departure_airport 
          AND fl2.scheduled_departure > fl1.scheduled_arrival

          WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 
          AND fl2.scheduled_arrival <= $5
          AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
          AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0

    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM a3gs7d.flights fl1
    INNER JOIN a3gs7d.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN a3gs7d.flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 AND fl3.scheduled_departure > $3
    AND fl3.scheduled_arrival <= $5
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    SELECT * FROM a3gs7d.flights WHERE departure_airport = $1 AND 
    arrival_airport = $2 AND scheduled_departure >= $3
    AND (seats_available+waitlist_available-$4) >=0SELECT  
        (fl1.fl_price+fl2.fl_price)*.7 as "fl_price",

        fl1.scheduled_departure as "time_depfl1",
        fl1.scheduled_arrival as "time_arrfl1",
        fl1.departure_airport as "depfl1",
        fl1.arrival_airport as "arrfl1",

        fl2.scheduled_departure as "time_depfl2",
        fl2.scheduled_arrival as "time_arrfl2",
        fl2.departure_airport as "depfl2",
        fl2.arrival_airport as "arrfl2",

        fl1.flight_id as flight_id_1,
        fl1.flight_no as flight1,
        fl2.flight_id as flight_id_2,
        fl2.flight_no as flight2,
        fl1.aircraft_code as "aircraft_code1",
        fl2.aircraft_code as "aircraft_code2"

        FROM a3gs7d.flights fl1
        INNER JOIN a3gs7d.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport = $2
        AND fl1.arrival_airport NOT LIKE $2 
        AND fl2.departure_airport NOT LIKE $1 
        AND fl1.arrival_airport  = fl2.departure_airport 
        AND fl2.scheduled_departure > fl1.scheduled_arrival

        WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 
        AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
        AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
        
    SELECT  fl1.scheduled_departure as "time_depfl1",
    fl1.scheduled_arrival as "time_arrfl1",
    fl1.departure_airport as "depfl1",
    fl1.arrival_airport as "arrfl1",
    (fl1.fl_price+fl2.fl_price+fl3.fl_price)*.6 as "fl_price",

    fl2.scheduled_departure as "time_depfl2",
    fl2.scheduled_arrival as "time_arrfl2",
    fl2.departure_airport as "depfl2",
    fl2.arrival_airport as "arrfl2",

    fl3.scheduled_departure as "time_depfl3",
    fl3.scheduled_arrival as "time_arrfl3",
    fl3.departure_airport as "depfl3",
    fl3.arrival_airport as "arrfl3",

    fl1.flight_id as flight_id_1,
    fl1.flight_no as flight1,
    fl2.flight_id as flight_id_2,
    fl2.flight_no as flight2,
    fl3.flight_id as flight_id_3,
    fl3.flight_no as flight3,
    fl1.aircraft_code as "aircraft_code1",
    fl2.aircraft_code as "aircraft_code2",
    fl3.aircraft_code as "aircraft_code3"

    FROM a3gs7d.flights fl1
    INNER JOIN a3gs7d.flights fl2 ON fl1.departure_airport = $1 AND  fl2.arrival_airport NOT LIKE $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND fl2.departure_airport NOT LIKE $1
    AND fl1.arrival_airport  = fl2.departure_airport 
    AND fl2.scheduled_departure > fl1.scheduled_arrival

    INNER JOIN a3gs7d.flights fl3 ON fl1.departure_airport = $1 AND  fl3.arrival_airport = $2
    AND fl1.arrival_airport NOT LIKE $2 AND fl2.arrival_airport NOT LIKE $2 
    AND (fl2.departure_airport NOT LIKE $1 AND fl3.departure_airport NOT LIKE $1)
    AND fl1.arrival_airport  = fl2.departure_airport AND fl2.arrival_airport  = fl3.departure_airport 
    AND fl3.scheduled_departure > fl2.scheduled_arrival

    WHERE fl1.scheduled_departure >= $3 AND fl2.scheduled_departure > $3 AND fl3.scheduled_departure > $3
    AND (fl1.seats_available+fl1.waitlist_available-$4) >= 0
    AND (fl2.seats_available+fl2.waitlist_available-$4) >= 0
    AND (fl3.seats_available+fl3.waitlist_available-$4) >= 0
    
                  INSERT INTO a3gs7d.bookings(book_ref,no_of_travellers) 
                  VALUES($1,$2) RETURNING *
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM a3gs7d.aircraft_seats ast
                    INNER JOIN a3gs7d.seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from a3gs7d.ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM a3gs7d.aircraft_seats ast
                    INNER JOIN a3gs7d.seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from a3gs7d.ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM a3gs7d.aircraft_seats ast
                    INNER JOIN a3gs7d.seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from a3gs7d.ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                
                    SELECT ast.seat_no, sc.fare_price as seat_price, sc.fare_conditions FROM a3gs7d.aircraft_seats ast
                    INNER JOIN a3gs7d.seatConditions sc ON sc.fare_id = ast.fare_id
                    WHERE ast.flight_id = $1 AND ast.seat_no NOT IN (SELECT seat_no from a3gs7d.ticket_flights where flight_id = $1)
                    ORDER BY ast.seat_no ASC;
                SELECT * FROM a3gs7d.airports ORDER BY airport_nameSELECT * FROM a3gs7d.airports ORDER BY airport_nameSELECT booking_payments.amount, booking_payments.book_ref, tickets.ticket_no
              from a3gs7d.booking_payments 
              INNER JOIN a3gs7d.bookings ON bookings.book_ref = booking_payments.book_ref
              INNER JOIN a3gs7d.tickets ON tickets.book_ref = bookings.book_ref
              WHERE tickets.ticket_no = $1 AND booking_payments.amount <0SELECT passengers.last_name,passengers.first_name,tickets.ticket_no, tickets.book_ref FROM  a3gs7d.tickets 
            INNER JOIN a3gs7d.passengers ON passengers.passengerid = tickets.passengerid 
            WHERE isinwaitlist = '1'Select *, a.airline_name from a3gs7d.flights f 
    INNER JOIN a3gs7d.airlines a ON f.airline_id = a.airline_id 
    ORDER BY flight_id;
    SELECT * FROM a3gs7d.airports ORDER BY airport_nameSELECT * FROM a3gs7d.airports ORDER BY airport_name