ER Link: https://www.dropbox.com/s/u2f1ykb73l43t6z/Copy%20of%20ER-3380.pdf?dl=0
Video Link: https://www.youtube.com/watch?v=HhZx9JDozmY&feature=youtu.be

########################		########################
######################## ABOUT THE VIDEO ########################
########################		########################
In this video, I always pick ABI and LAX because I did not have routes for the other cities.

First I will walk you through the non-round trip at 0:21
-At 1:39 I showed how the refund page work, before and after the customer cancel the ticket.
-At 2:15 showed the check-in portal that will show everything on the confirmation, in case customers need those information later on.

Round trip: by selecting departure date and return date:
At 2:40 to 4:00. 

-At 5:14 I showed that I used flight_id = 42
-At 5:32 I changed the seat_available to 0, and balanced the seat_taken = 50, and hit Edit to save. Then I proceeded to payment and in the confirmation, which told me I was on the waitlist. (At 5:59 I have refresh the flight list to show that 2 waitlist are taken off from waitlist_available column - from 10 to only 8 now)

+++Check info for clerk page+++
6:23, you can see the flight information for flight 42, there was total 2 passengers on that flight. ( they’re on waitlist because I manually set 0 seat available in that flight)

6:26, clerk can check to see any passenger in the waitlist - as you can see, there were 2 passengers in the waitlist.

###########################################################################################
########################Readme instructions################################################
###########################################################################################
Download the files, unzip. You will have 1 folder client, 1 folder server, readme file and a sql_insert.sql file to create tables and insert data into the DB.
Go to FileZilla/SSH, copy the sql file named “sql_insert.sql” into your database.
Using Visual Studio Code, click on “Open Folder”, select the directory to where the files are, ONLY select the CLIENT folder, add that folder , then add SERVER folder.
To test find out if you do it correctly, whenever you open the html files with a live server, it should display:
→ something like this: http://127.0.0.1:5500/index.html 
→ Not like this: 	 http://127.0.0.1:5500/client/index.html
Open a new terminal on Visual Studio Code for SERVER.
Make sure to install nodejs, to check to see if you did install it, type “node -v” in the server terminal. If it shows something like v14.15.1, then you have successfully installed nodejs. 

!!! You will also need to install the “Live Server” extension on VS Code. Go to the left side of the window, click on the last icon that looks like a rubik-cube with one piece missing, on the search bar type “live server” (or locate it in the menu Views/Extensions). Search “Live Server” and install it.
Install all of the dependencies by 2 ways:
 opening terminal/cmd, enter command “cd” into the server folder ( something like “cd server”). Then type “npm install” in the server terminal.
Or using Visual Code terminal in the server folder. Then type “npm install” in the server terminal.
Go to db.js, change your username and password to be able to connect to the database. Make sure to change it, or else you cannot test the website.
Go to index.js, at “const schema = “xxxxx””, replace xxxxx with either your coscxxxx number or schema name ‘A3GS7D’/’a3gs7d’
So it will become -> const schema = “a3gs7d”
After it has finished installing. In the server terminal, type “node index.js” to start the server.
BEFORE you run the files on the client side, make sure to open a new window to connect to the class’ database. Run the “sql_insert.sql” file first before checking on the client side.
Login > cd to the directory where you previously put the sql file > psql -d COSC3380 > set schema ‘A3GS7D’; > \i sql_insert.sql

Go back to the server window, go to the Client folder, click on “index.html”, right click where you open it, select “Open with Live Server”. A window will automatically pop-up showing the website.


###########################################################################################
#####################################ABOUT THE WEBSITE#####################################
###########################################################################################
################TICKET BOOKING
To select/search for a flight, click on the drop-down menu to choose the desired airports, click on the dates to select departure/return dates. You can only select up to 5 passengers per booking reservation.
!!! Note: Destinations that are not in the database will not display flight information, “No result” is what you would expect to see if that flight route is not in the database
After clicking “Order ticket now”, flight information will be displayed on the right hand side (make sure to scroll up to the top to check because sometimes the flights are shown up there)
Select the direction that you want, there are direct flights, indirect flights with 1 or more connections, prices will vary depending on your choice. Click “Choose” (it will display 2 flights for departing and returning flights)
It will then prompt you to enter the passengers’ personal information as well as ask you to select the seat and fare that you want. Movie and meal options are also available, you just need to tick on the boxes. Each passenger can have a maximum of 2 checked bags which are also included in that section.
After you have filled out everything, click on “Add Passenger”. If you have more than one passenger, you will need to fill out all information for everyone before being able to proceed to the next step.
You can also edit your name/phone number/etc after adding passenger, or you can choose to “Proceed to Payment” to enter payment information to finish the reservation.
After “Adding Payment”, a confirmation page will be displayed showing all of the necessary information for your flights.
-------------------------------------------------------------------------------------------------------------------------------
################CHECK-IN
To check-in onto a flight, go to the “Check-in” section on the top of the home page, click on it.
There will be a screen asking you to enter the information to begin check-in. After you finish with that, a boarding pass will show up with the flight details
-------------------------------------------------------------------------------------------------------------------------------
################TICKET CANCELLATION
Click on “Cancel Ticket” at the top of the page, it will redirect you to the ticket cancellation page.
Enter ticket number, booking reference, booking date, first name and last name; hit “Cancel Ticket”. If it’s successfully cancelled, it will display a message saying that ticket has been successfully cancelled
After that you can check for your refund status
-------------------------------------------------------------------------------------------------------------------------------
################TICKET REFUND
Click on the “Refund Status” section, enter your ticket number to check for the refund status.
If the ticket is cancelled earlier, it will display the refund amount for the ticket. If not, then it will display a message indicating that you need to speak with the airline staffs to check for the amount.
-------------------------------------------------------------------------------------------------------------------------------
################AIRPORT PERSONNEL
Click on the “Airline personnel” to check/edit flight information
You can increase/decrease the amount of seats available per flight or edit the waitlist total as well as make changes to flight price. Make sure to click on “Edit” when you do
################CHECK INFO FOR CLERK
there are 2 boxes
1. Flight Information: use to look up how many passenger in specific flightID. Enter a number of flight ID and it will show flight information.
2. Check Waitlist: use to list all the tickets that are in wait list (list include last name, first name, ticket number, and book refference)
-------------------------------------------------------------------------------------------------------------------------------
